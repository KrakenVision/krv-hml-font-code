<?php return array (
  'parameters' => 
  array (
    'database_host' => '127.0.0.1',
    'database_port' => '',
    'database_name' => 'prestashop',
    'database_user' => 'root',
    'database_password' => '',
    'database_prefix' => 'ps_',
    'database_engine' => 'InnoDB',
    'mailer_transport' => 'smtp',
    'mailer_host' => '127.0.0.1',
    'mailer_user' => NULL,
    'mailer_password' => NULL,
    'secret' => '9aebdkO0HSffZJnC4d38NZUODiyv1O5Lj22RO0xYbxi13a5ofhVStDPJ',
    'ps_caching' => 'CacheMemcache',
    'ps_cache_enable' => false,
    'ps_creation_date' => '2019-05-02',
    'locale' => 'es-ES',
    'cookie_key' => 'kAYJtb3hAtXbROHgxtMCWtyAsyHYnRwNQ0xLa2C0TpxkDstfWfKfW9B9',
    'cookie_iv' => 'P7GMMXSI',
    'new_cookie_key' => 'def0000025284546cafeb743053d0a89358403abeae835725f628e81cc81912b22f73540b00e8dc89f17924310023acfbfd8110b657d377d1af39a5e28405fa8a38d1c2b',
  ),
);